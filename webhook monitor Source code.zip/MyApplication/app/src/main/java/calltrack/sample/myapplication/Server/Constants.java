package calltrack.sample.myapplication.Server;

/**
 * Created by root on 18/10/16.
 */

public class Constants {

    public static final String INBOUND_URL ="call_ringing" ;
    public static final String PICKEDUP_URL ="call_picked" ;
    public static final String CALLEDND_URL = "call_ended";

    public static String BASE_URL="http://echo.jsontest.com/title/";
    public static String BASE_URL_new="http://somedomain.com/webhook?phone_number=&caller=";


}
